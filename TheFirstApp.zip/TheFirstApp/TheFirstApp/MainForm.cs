﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheFirstApp
{
    public partial class MainForm : Form
    {
        Random ran = new Random();
        public MainForm()
        {
            InitializeComponent();
        }

        private void button_variable_Click(object sender, EventArgs e)
        {
            String str = "Welcome to the variables";
            String str2 = str + " and do what";
            str += "\nHello World"; // is same as str =  str + "\nHello world";
            int i = 90;
            str2 = "hello " + i;
            //MessageBox.Show(str);
            //MessageBox.Show(i.ToString());

            ///////////// Array ///////////////////////
            int[] iArr = new int[10] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            int first = iArr[7];
            iArr[7] = 777;
            first = 909;
            //Check Transfer Data.jpg.
            MessageBox.Show("element  = " + iArr[7]); //777
            MessageBox.Show("First  = " + first); //6

            //for (int x = 0; x < iArr.Length; ++x)
            //{
            //    MessageBox.Show("element  at " + x + " = " + iArr[x]);
            //}
            //MessageBox.Show("element  = " + first);

            String[] myArr = new String[2] { "Welcome_1", "Welcome_2" };
            ///////////// Array ///////////////////////
            ///
            //Q.0) Show all elements in an integer array in one message box;
            //Q.1) use for loop and create an array of 25 Strings like this, "Ashish_1", "Ashish_2" , ...., "Ashish_25"
            //Q.2) use for loop and create array of 100 random integers. using ran.Next()
            //Q.3) in the above example use a fo loop to find max and min.
            //Q.4) From the Q.2 array, create another array of only even numbers.


        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape) Close();
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
